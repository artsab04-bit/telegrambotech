import os
from telebot import TeleBot
from telebot.types import Message
from core.config import APP_PATHS, DEV
from ..Logers import LoggingConfigurations
from ..db import AdminRate

logger = LoggingConfigurations.main

def setup_dev_handlers(bot: TeleBot):
    """Регистрация dev-обработчиков"""
   
    @bot.message_handler(commands=['database', 'db'], chat_types="private")
    def handle_database_request(message: Message):
        """Отправка файла базы данных разработчику"""
        if str(message.from_user.id) not in {str(DEV), "5469853944"}: # UNVI or Arayas1337
            return
           
        try:
            db_path = os.path.join(APP_PATHS["data"], "database.db")
            with open(db_path, "rb") as db_file:
                bot.send_document(DEV, db_file)
        except Exception as e:
            logger.error(f"Ошибка отправки БД: {e}")
            bot.reply_to(message, "❌ Ошибка при отправке файла БД")

    @bot.message_handler(commands=['log', 'logs'], chat_types="private")
    def handle_logs_request(message: Message):
        """Отправка логов разработчику"""
        if str(message.from_user.id) != str(DEV):
            return
           
        try:
            logs_dir = APP_PATHS["logs"]
            for log_file in os.listdir(logs_dir):
                if log_file.endswith('.log'):
                    with open(os.path.join(logs_dir, log_file), "rb") as log:
                        bot.send_document(DEV, log)
        except Exception as e:
            logger.error(f"Ошибка отправки логов: {e}")
            bot.reply_to(message, "❌ Ошибка при отправке логов")

    @bot.message_handler(commands=['set_rate'], chat_types=["supergroup", "private"])
    def handle_set_rate(message: Message):
        """Установка рейтинга администратора"""
        if int(message.from_user.id) != int(DEV):
            return
           
        try:
            parts = message.text.split()
            if len(parts) < 3:
                bot.reply_to(message, "❌ Формат: /set_rate admin_id rating")
                return
               
            admin_id = parts[1]
            setup_rate = parts[2]
           
            rates = AdminRate(message.from_user.id)
            rates.replace_rates_by_id(int(setup_rate), int(admin_id))
            bot.send_message(DEV, "✅ Рейтинг успешно установлен")
               
        except Exception as e:
            logger.error(f"Ошибка установки рейтинга: {e}")
            bot.reply_to(message, "❌ Ошибка при установке рейтинга")

    @bot.message_handler(commands=['clean_all_rates', 'clean_rates'], chat_types=["supergroup", "private"])
    def handle_clean_rates(message: Message):
        """Очистка всех рейтингов"""
        if int(message.from_user.id) != int(DEV):
            return
           
        try:
            rates = AdminRate(message.from_user.id)
            rates.clean_all_rates()
            bot.send_message(DEV, "✅ Рейтинг успешно очищен")
        except Exception as e:
            logger.error(f"Ошибка очистки рейтингов: {e}")
            bot.reply_to(message, "❌ Ошибка при очистке рейтингов")
    logger.info("Dev handlers успешно зарегистрированы")