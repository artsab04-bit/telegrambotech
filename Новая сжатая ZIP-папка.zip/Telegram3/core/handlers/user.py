# Изменения: Убраны кнопки после выбора "Мне нужен оператор" с помощью edit_message_reply_markup (проблема 3). Добавлена задержка на кнопки для предотвращения спама. Улучшена пересылка сообщений с фиксом для медиа. Добавлена кнопка "💬 Чат пользователей Hyper" с выводом ссылки из settings (проблема 5). Добавлена функция напоминания о неактивности тикета.
from telebot import TeleBot
from telebot.types import Message, ReplyKeyboardRemove
from telebot.util import content_type_media
from core.markups import language_markup, main_menu_markup
from core.db import User, Ticket, BlackList, Messages, Settings
from core.types import AppMessage
from core.Logers import LoggingConfigurations
from core.config import GROUP_ID, DEV, ticket_creation_lock
from data.TEXT_MESSAGES import HELLO, WELCOME, REMINDER, CHAT_LINK, CREATED, FORM, NIGHT_MODE_OFF
import uuid
import time
import pytz
from datetime import datetime
import telebot.apihelper
from telebot.types import ReplyKeyboardMarkup, KeyboardButton

logger = LoggingConfigurations.main

def setup_user_handlers(bot: TeleBot):
    @bot.message_handler(commands=["start"])
    def start(message: Message):
        user_id = message.from_user.id
        username = message.from_user.username or message.from_user.full_name
        user_obj = User(user_id, username)
        try:
            current_time = int(time.time())
            if current_time - user_obj.userdata.last_button_time < 1:
                bot.send_message(user_id, "Не спамьте командами!" if user_obj.userdata.language == 'ru' else "Don't spam commands!")
                return
            user_obj.set_last_button_time(current_time)
            if user_obj.userdata.ticketID != -99999:
                bot.send_message(user_id, "У вас открыт тикет, если хотите вернуться в главное меню, попросите саппорта закрыть тикет." if user_obj.userdata.language == 'ru' else "You have an open ticket, if you want to return to the main menu, ask support to close the ticket.")
                return
            if not user_obj.userdata.language:
                bot.send_message(user_id, "Выберите язык / Select language:", reply_markup=language_markup())
            else:
                user_obj.set_state("main_menu")
                bot.send_message(
                    user_id,
                    WELCOME[user_obj.userdata.language],
                    reply_markup=main_menu_markup(user_obj.userdata.language)
                )
        finally:
            user_obj.exit()

    @bot.message_handler(commands=["language"])
    def change_language(message: Message):
        user_id = message.from_user.id
        user_obj = User(user_id)
        try:
            bot.send_message(
                user_id,
                "Выберите язык / Select language:",
                reply_markup=language_markup()
            )
        finally:
            user_obj.exit()

    @bot.message_handler(commands=["close"], chat_types=["private"])
    def close_ticket_user(message: Message):
        user_id = message.from_user.id
        user_obj = User(user_id)
        ticket_obj = Ticket()
        try:
            ticket_id = ticket_obj.get_by_user_id(user_id)
            if ticket_id:
                ticket_obj.close_ticket_manual(ticket_id, user_id, bot)
            else:
                bot.send_message(user_id, "Нет открытого тикета.")
        finally:
            user_obj.exit()
            del ticket_obj

    @bot.message_handler(func=lambda m: m.text in ["🙋‍♂️Мне нужен оператор", "🙋‍♂️I need an operator"])
    def handle_operator_button(message: Message, is_button=True):
        user_id = message.from_user.id
        user_name = message.from_user.username or message.from_user.full_name
        user_obj = User(user_id, user_name)
        ticket_obj = Ticket()
        try:
            current_time = int(time.time())
            if current_time - user_obj.userdata.last_button_time < 1:
                bot.send_message(user_id, "Не спамьте!" if user_obj.userdata.language == 'ru' else "Don't spam!")
                return
            user_obj.set_last_button_time(current_time)
            if BlackList().is_blacklisted(user_id):
                ban_info = BlackList().get_ban_info(user_id)
                response = f"⛔ Вы забанены.\nПричина: {ban_info[2] or 'не указана'}\nДата: {ban_info[3]}"
                bot.send_message(user_id, response)
                return
            if user_obj.userdata.ticketID != -99999:
                bot.send_message(user_id, "У вас уже открыт тикет." if user_obj.userdata.language == 'ru' else "You already have an open ticket.")
                return
            with ticket_creation_lock:
                topic = f"{user_name} | {uuid.uuid4().hex[:8]}"
                try:
                    forum_topic = bot.create_forum_topic(GROUP_ID, topic)
                    ticket_id = forum_topic.message_thread_id
                    ticket_obj.create(ticket_id, user_id, user_name)
                    bot.send_message(user_id, CREATED[user_obj.userdata.language])
                    lang_text = "Русский" if user_obj.userdata.language == 'ru' else "English"
                    bot.send_message(
                        GROUP_ID,
                        f"✅ Новый тикет {ticket_id}:\nID: {user_id}\nUsername: @{user_name}\nLanguage: {lang_text}",
                        message_thread_id=ticket_id
                    )
                    bot.send_message(user_id, FORM[user_obj.userdata.language])
                    user_obj.set_ticket(ticket_id)
                    user_obj.set_state("ticket_mode")
                except Exception as create_err:
                    logger.error(f"Ошибка создания темы: {create_err}")
                    bot.send_message(user_id, "⚠️ Ошибка при создании тикета. Попробуйте позже." if user_obj.userdata.language == 'ru' else "⚠️ Error creating ticket. Try later.")
                    return
            if is_button:
                try:
                    bot.edit_message_reply_markup(user_id, message.message_id, reply_markup=None)  # Убрать кнопки
                    return
                except Exception as edit_err:
                    logger.warning(f"Не удалось убрать кнопки после создания тикета: {edit_err}")
            try:
                bot.edit_forum_topic(
                    chat_id=GROUP_ID,
                    message_thread_id=ticket_id,
                    name=topic
                )
            except Exception as edit_err:
                logger.warning(f"Не удалось обновить тему: {edit_err}")
            time.sleep(1)
            for attempt in range(3):
                try:
                    msg = bot.copy_message(
                        GROUP_ID,
                        message.chat.id,
                        message.message_id,
                        message_thread_id=ticket_id
                    )
                    Messages().add(AppMessage(
                        TicketID=ticket_id,
                        Message=message,
                        TicketMessageID=msg.message_id,
                        MessageFromID=user_id
                    ))
                    ticket_obj.update_last_activity(ticket_id)
                    break
                except telebot.apihelper.ApiTelegramException as e:
                    if e.error_code == 429:
                        retry_after = int(e.result_json['parameters']['retry_after'])
                        time.sleep(retry_after + 1)
                    else:
                        raise
            else:
                logger.error(f"Ошибка копирования после 3 попыток: {e}")
                bot.send_message(
                    GROUP_ID,
                    "Ошибка при обработке сообщения пользователя" if user_obj.userdata.language == 'ru' else "Error processing user message",
                    message_thread_id=ticket_id
                )
                bot.send_message(
                    user_id,
                    "⚠️Не спамьте сообщениями!" if user_obj.userdata.language == 'ru' else "⚠️Do not spam messages!"
                )
        finally:
            user_obj.exit()
            del ticket_obj

    @bot.message_handler(func=lambda m: m.text in ["💬 Чат пользователей Hyper", "💬 Hyper Users Chat"])
    def show_chat_link(message: Message):
        settings = Settings()
        chat_link = settings.get('chat_link') or CHAT_LINK['ru']
        bot.send_message(message.chat.id, f"Ссылка на чат: {chat_link}")
        del settings

    def forward_to_ticket(bot, message, ticket_id, ticket_obj):
        prefix = f"<b>Ответ от пользователя:</b>" if message.chat.id == GROUP_ID else ""
        if message.content_type == "text":
            bot.send_message(
                user_obj.userdata.id if message.chat.id == GROUP_ID else GROUP_ID,
                f"{prefix}\n{message.text}",
                message_thread_id=ticket_id if message.chat.id != GROUP_ID else None
            )
        else:
            bot.copy_message(
                user_obj.userdata.id if message.chat.id == GROUP_ID else GROUP_ID,
                message.chat.id,
                message.message_id,
                message_thread_id=ticket_id if message.chat.id != GROUP_ID else None
            )
        ticket_obj.update_last_activity(ticket_id)
