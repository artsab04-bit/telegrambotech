import sqlite3
from datetime import datetime
from telebot.types import Message
from ..Logers import LoggingConfigurations
from ..types import AppMessage
from ..config import APP_PATHS
logger = LoggingConfigurations.db
class Messages:
    def __init__(self):
        self.conn = sqlite3.connect(APP_PATHS["database"])
        self._create_table()
    def _create_table(self):
        try:
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ticket_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    content_type TEXT NOT NULL,
                    content_text TEXT,
                    message_id INTEGER NOT NULL,
                    date DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(ticket_id) REFERENCES tickets(thread_id),
                    FOREIGN KEY(user_id) REFERENCES users(id)
                )
            """)
            self.conn.commit()
        except sqlite3.Error as e:
            logger.error(f"Ошибка создания таблицы messages: {e}")
            raise
    def add(self, app_message: AppMessage):
        cursor = self.conn.cursor()
        try:
            cursor.execute("""
                INSERT INTO messages (ticket_id, user_id, content_type, content_text, message_id, date)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                app_message.TicketID,
                app_message.MessageFromID,
                app_message.Message.content_type,
                app_message.Message.text if app_message.Message.content_type == "text" else None,
                app_message.TicketMessageID,
                datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # ИЗМЕНЕНО: преобразование в строку
            ))
            self.conn.commit()
            return True
        except sqlite3.Error as e:
            logger.error(f"Ошибка добавления сообщения: {e}")
            raise
        finally:
            cursor.close()
    def get_by_ticket(self, ticket_id: int):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM messages WHERE ticket_id = ? ORDER BY date", (ticket_id,))
        result = cursor.fetchall()
        cursor.close()
        return result
    def delete_by_ticket(self, ticket_id: int):
        cursor = self.conn.cursor()
        cursor.execute("DELETE FROM messages WHERE ticket_id = ?", (ticket_id,))
        self.conn.commit()
        cursor.close()
    def get_last_user_message_time(self, ticket_id: int, user_id: int):
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT date FROM messages
            WHERE ticket_id = ? AND user_id = ?
            ORDER BY date DESC LIMIT 1
        """, (ticket_id, user_id))
        result = cursor.fetchone()
        cursor.close()
        if result:
            return datetime.strptime(result[0], '%Y-%m-%d %H:%M:%S')
        return None
    def __del__(self):
        self.conn.close()