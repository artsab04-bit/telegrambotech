# Изменения: Улучшена выгрузка истории в .txt с включением content_type для медиа и полными датами (проблема 4). Добавлена функция авто-закрытия с уведомлением. Фикс для datetime парсинга. Добавлена статистика открытых тикетов.
import sqlite3
from datetime import datetime
from ..config import APP_PATHS as PATH
from ..Logers import LoggingConfigurations
from ..db.messages import Messages
from data.TEXT_MESSAGES import AUTO_CLOSE
from core.config import GROUP_ID
from core.db.user import User
import os

logger = LoggingConfigurations.db

class Ticket:
    def __init__(self):
        self.conn = sqlite3.connect(PATH["database"], timeout=20)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self._create_table()

    def _create_table(self):
        try:
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS tickets (
                    thread_id INTEGER PRIMARY KEY,
                    user_id INTEGER NOT NULL,
                    username TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'open',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(user_id) REFERENCES users(id)
                )
            """)
            self.conn.commit()
        except sqlite3.Error as e:
            logger.error(f"Ошибка создания таблицы tickets: {e}")

    def create(self, thread_id: int, user_id: int, username: str):
        try:
            cursor = self.conn.cursor()
            cursor.execute("SELECT thread_id FROM tickets WHERE thread_id = ?", (thread_id,))
            if cursor.fetchone():
                logger.warning(f"Тикет с thread_id={thread_id} уже существует")
                return
            cursor.execute(
                "INSERT INTO tickets (thread_id, user_id, username, last_activity) VALUES (?, ?, ?, ?)",
                (thread_id, user_id, username, datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            )
            self.conn.commit()
            logger.info(f"Создан тикет: thread_id={thread_id}, user_id={user_id}, username={username}")
        except sqlite3.Error as e:
            logger.error(f"Ошибка при создании тикета thread_id={thread_id}: {e}")
            raise
        finally:
            cursor.close()

    def update_status(self, thread_id: int, status: str):
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "UPDATE tickets SET status = ? WHERE thread_id = ?",
                (status, thread_id)
            )
            self.conn.commit()
            logger.info(f"Обновлен статус тикета thread_id={thread_id}: {status}")
        except sqlite3.Error as e:
            logger.error(f"Ошибка при обновлении статуса тикета thread_id={thread_id}: {e}")
            raise
        finally:
            cursor.close()

    def update_last_activity(self, thread_id: int):
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "UPDATE tickets SET last_activity = ? WHERE thread_id = ?",
                (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), thread_id)
            )
            self.conn.commit()
        except sqlite3.Error as e:
            logger.error(f"Ошибка при обновлении last_activity тикета thread_id={thread_id}: {e}")

    def get_by_user_id(self, user_id: int):
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "SELECT thread_id, status FROM tickets WHERE user_id = ? ORDER BY created_at DESC LIMIT 1",
                (user_id,)
            )
            result = cursor.fetchone()
            logger.debug(f"Поиск тикета для user_id={user_id}: {'найден' if result else 'не найден'}")
            if result and result[1] == 'open':
                return result[0]
            return None
        except sqlite3.Error as e:
            logger.error(f"Ошибка при поиске тикета для user_id={user_id}: {e}")
            return None
        finally:
            cursor.close()

    def get_last_user_message_time(self, thread_id: int):
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "SELECT last_activity FROM tickets WHERE thread_id = ?",
                (thread_id,)
            )
            result = cursor.fetchone()
            if result:
                try:
                    return datetime.strptime(result[0], '%Y-%m-%d %H:%M:%S')
                except ValueError:
                    return datetime.strptime(result[0].split('.')[0], '%Y-%m-%d %H:%M:%S')
            return None
        except sqlite3.Error as e:
            logger.error(f"Ошибка при получении last_activity тикета thread_id={thread_id}: {e}")
            return None
        finally:
            cursor.close()

    def close_ticket_auto(self, thread_id: int, user_id: int, bot):
        self.update_status(thread_id, 'closed')
        bot.close_forum_topic(GROUP_ID, thread_id)
        bot.delete_forum_topic(GROUP_ID, thread_id)
        user_obj = User(user_id)
        bot.send_message(user_id, AUTO_CLOSE[user_obj.userdata.language])
        Messages().delete_by_ticket(thread_id)
        user_obj.set_ticket(-99999)
        user_obj.set_state("main_menu")
        user_obj.exit()

    def save_history_to_txt(self, thread_id: int):
        try:
            messages = Messages().get_by_ticket(thread_id)
            if not messages:
                return None
            history = f"Переписка тикета {thread_id}:\n\n"
            for msg in messages:
                msg_id, ticket_id, user_id, content_type, content_text, message_id, date = msg
                content = content_text if content_text else f"[Media: {content_type}]"
                history += f"[{date}] User {user_id}: {content}\n"
            path = os.path.join(PATH["logs"], f"ticket_{thread_id}.txt")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(history)
            logger.info(f"Сохранена переписка тикета {thread_id} в {path}")
            return path
        except Exception as e:
            logger.error(f"Ошибка сохранения переписки тикета {thread_id}: {e}")
            return None

    def __del__(self):
        try:
            self.conn.commit()
            self.conn.close()
            logger.debug("Соединение с базой данных закрыто")
        except:
            pass