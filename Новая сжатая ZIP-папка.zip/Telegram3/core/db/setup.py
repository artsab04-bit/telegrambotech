import sqlite3
import os
from ..config import APP_PATHS, DEV
from ..Logers import LoggingConfigurations
from ..exceptions import SetupError
logger = LoggingConfigurations.db
class DatabaseSetup:
    REQUIRED_TABLES = {
        'users': [
            ('id', 'INTEGER NOT NULL UNIQUE'),
            ('username', 'TEXT'),
            ('ticketID', 'INTEGER'),
            ('language', 'TEXT DEFAULT NULL'),
            ('state', 'TEXT DEFAULT "main_menu"'),
            ('last_button_time', 'INTEGER DEFAULT 0'),
            ('role', 'TEXT DEFAULT "user"'),
            ('last_message_time', 'INTEGER DEFAULT 0'),
            ('created_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP')
        ],
        'tickets': [
            ('thread_id', 'INTEGER PRIMARY KEY'),
            ('user_id', 'INTEGER NOT NULL'),
            ('username', 'TEXT NOT NULL'),
            ('status', 'TEXT NOT NULL DEFAULT "open"'),
            ('created_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
            ('last_activity', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'),
            ('FOREIGN KEY(user_id)', 'REFERENCES users(id)')
        ],
        'messages': [
            ('id', 'INTEGER PRIMARY KEY AUTOINCREMENT'),
            ('ticket_id', 'INTEGER NOT NULL'),
            ('user_id', 'INTEGER NOT NULL'),
            ('content_type', 'TEXT NOT NULL'),
            ('content_text', 'TEXT'),
            ('message_id', 'INTEGER NOT NULL'),
            ('date', 'DATETIME DEFAULT CURRENT_TIMESTAMP'),
            ('FOREIGN KEY(ticket_id)', 'REFERENCES tickets(thread_id)'),
            ('FOREIGN KEY(user_id)', 'REFERENCES users(id)')
        ],
        'blacklist': [
            ('id', 'INTEGER PRIMARY KEY'),
            ('addedby', 'INTEGER NOT NULL'),
            ('reason', 'TEXT'),
            ('created_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP')
        ],
        'specialists': [
            ('user_id', 'INTEGER PRIMARY KEY'),
            ('role', 'TEXT NOT NULL')
        ],
        'AdminRate': [
            ('id', 'INTEGER'),
            ('rate', 'INTEGER'),
            ('date', 'TEXT'),
            ('uid', 'INTEGER')
        ]
    }
    INDEXES = [
        ('idx_blacklist_id', 'blacklist', ['id']),
        ('idx_users_id', 'users', ['id']),
        ('idx_tickets_user_id', 'tickets', ['user_id']),
        ('idx_messages_ticket_id', 'messages', ['ticket_id']),
        ('idx_specialists_user_id', 'specialists', ['user_id'])
    ]
    def __init__(self):
        self.db_path = APP_PATHS["database"]
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
    def setup_database(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA foreign_keys = ON")
            self._create_tables(conn)
            self._add_default_admin(conn)
            self._create_indexes(conn)
            self._execute_setup_scripts(conn)
            self._migrate_tables(conn)
            self._verify_database(conn)
            logger.info("База данных успешно инициализирована")
    def _create_tables(self, conn):
        for table_name, columns in self.REQUIRED_TABLES.items():
            columns_sql = ", ".join([f"{col[0]} {col[1]}" for col in columns if "FOREIGN KEY" not in col[0]])
            foreign_keys = ", ".join([col[0] + " " + col[1] for col in columns if "FOREIGN KEY" in col[0]])
            if foreign_keys:
                if columns_sql:
                    columns_sql += ", "
                columns_sql += foreign_keys
            conn.execute(f"CREATE TABLE IF NOT EXISTS {table_name} ({columns_sql})")
        conn.commit()
    def _add_default_admin(self, conn):
        """Добавляет DEV как admin в specialists, если не существует"""
        conn.execute("INSERT OR IGNORE INTO specialists (user_id, role) VALUES (?, ?)", (DEV, 'admin'))
        conn.commit()
        logger.info(f"DEV {DEV} добавлен как admin в specialists")
    def _create_indexes(self, conn):
        for index_name, table_name, columns in self.INDEXES:
            columns_str = ", ".join(columns)
            conn.execute(f"CREATE INDEX IF NOT EXISTS {index_name} ON {table_name} ({columns_str})")
        conn.commit()
    def _execute_setup_scripts(self, conn):
        setup_script = APP_PATHS.get("setup_sql")
        if setup_script and os.path.exists(setup_script):
            with open(setup_script, 'r', encoding='utf-8') as f:
                conn.executescript(f.read())
            logger.info("Дополнительный SQL-скрипт выполнен")
    def _verify_database(self, conn):
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        existing_tables = {row[0].lower() for row in cursor.fetchall()}
        for required_table in self.REQUIRED_TABLES:
            if required_table.lower() not in existing_tables:
                raise SetupError(f"Таблица {required_table} не создана")
        logger.info(f"Проверено таблиц: {len(existing_tables)}")
    def _migrate_tables(self, conn):
        """ДОБАВЛЕНО: Миграция для добавления отсутствующих столбцов"""
        cursor = conn.cursor()
        # Для таблицы users: добавить last_message_time если нет
        cursor.execute("PRAGMA table_info(users)")
        columns = [col[1] for col in cursor.fetchall()]
        if 'last_message_time' not in columns:
            cursor.execute("ALTER TABLE users ADD COLUMN last_message_time INTEGER DEFAULT 0")
            logger.info("Добавлен столбец last_message_time в users")
        if 'created_at' not in columns:
            conn.execute("PRAGMA foreign_keys = OFF")
            cursor.execute("DROP TABLE IF EXISTS users_temp")
            cursor.execute("CREATE TABLE users_temp AS SELECT * FROM users")
            cursor.execute("DROP TABLE users")
            cursor.execute("""
                CREATE TABLE users (
                    id INTEGER NOT NULL UNIQUE,
                    username TEXT,
                    ticketID INTEGER,
                    language TEXT DEFAULT NULL,
                    state TEXT DEFAULT "main_menu",
                    last_button_time INTEGER DEFAULT 0,
                    role TEXT DEFAULT "user",
                    last_message_time INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            cursor.execute("""
                INSERT INTO users (id, username, ticketID, language, state, last_button_time, role, last_message_time)
                SELECT id, username, ticketID, language, state, last_button_time, role, last_message_time FROM users_temp
            """)
            cursor.execute("DROP TABLE users_temp")
            conn.execute("PRAGMA foreign_keys = ON")
            logger.info("Миграция users с добавлением created_at завершена")
        # Для таблицы messages: добавить date если нет
        cursor.execute("PRAGMA table_info(messages)")
        columns = [col[1] for col in cursor.fetchall()]
        if 'date' not in columns:
            cursor.execute("ALTER TABLE messages ADD COLUMN date DATETIME DEFAULT CURRENT_TIMESTAMP")
            logger.info("Добавлен столбец date в messages")
        conn.commit()
def setup_database():
    return DatabaseSetup().setup_database()