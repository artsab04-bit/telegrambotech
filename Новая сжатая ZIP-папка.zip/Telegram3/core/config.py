# -*- coding: utf-8 -*-
import os
from pathlib import Path
from threading import Lock  # Импорт для создания блокировки синхронизации

# Токен и настройки
TOKEN = "7994937212:AAH-I3TCFLH6HYNEwy6h7X3SDRUXyC-OblE"
DEV = 1625484309
OWNER = 1625484309
GROUP_ID = -1002761650694
SUBSCRIBE_CHAT_IDS = [-1001690577317, -1001822306804]
DEFAULT_LANGUAGE = 'ru'

# Блокировка синхронизации для создания тикетов, чтобы предотвратить условия гонки
ticket_creation_lock = Lock()

# Базовый путь
BASE_DIR = Path(__file__).resolve().parent.parent
# Полные пути к файлам
APP_PATHS = {
    "data": str(BASE_DIR / "data"),
    "logs": str(BASE_DIR / "data" / "logs"),
    "images": str(BASE_DIR / "data" / "images"),
    "database": str(BASE_DIR / "data" / "database.db"), # Полный путь к БД
    "setup_sql": str(BASE_DIR / "data" / "setup.sql") # Полный путь к SQL-скрипту
}
# Создаем необходимые директории
os.makedirs(APP_PATHS["logs"], exist_ok=True)
os.makedirs(APP_PATHS["images"], exist_ok=True)
import logging
class LoggingConfigurations:
    admin = logging.getLogger('admin')
    user = logging.getLogger('user')
    db = logging.getLogger('db')
    @staticmethod
    def setup_logging():
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s | %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(os.path.join(APP_PATHS["logs"], "bot.log")),
                logging.StreamHandler()
            ]
        )
LoggingConfigurations.setup_logging()