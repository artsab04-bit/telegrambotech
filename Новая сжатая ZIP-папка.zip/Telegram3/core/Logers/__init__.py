import logging
import uuid
from pathlib import Path
from dataclasses import dataclass
import os

from ..config import APP_PATHS as PATH

def _logger_setup(filename: str, level=logging.INFO):
    # Получаем путь к логам и создаём директорию если нужно
    logs_path = Path(PATH["logs"])
    logs_path.mkdir(parents=True, exist_ok=True)
    
    # Формируем полное имя файла
    filename = filename if filename.endswith(".log") else f"{filename}.log"
    full_path = logs_path / filename
    
    # Настраиваем логгер
    logger = logging.getLogger(str(uuid.uuid4()))
    formatter = logging.Formatter("%(asctime)s | %(levelname)s - %(message)s")
    
    # Обработчик для файла
    fileHandler = logging.FileHandler(full_path, mode='a')
    fileHandler.setFormatter(formatter)
    
    # Обработчик для вывода в консоль
    streamHandler = logging.StreamHandler()
    streamHandler.setFormatter(formatter)
    
    logger.setLevel(level)
    logger.addHandler(fileHandler)
    logger.addHandler(streamHandler)
    
    return logger

@dataclass
class LoggingConfigurations:
    main = _logger_setup("main", level=logging.INFO)
    db = _logger_setup("db", level=logging.INFO)
    critical = _logger_setup("critical", level=logging.INFO)