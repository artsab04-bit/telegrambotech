PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS users (
    id INTEGER NOT NULL UNIQUE,
    username TEXT,
    ticketID INTEGER,
    language TEXT DEFAULT NULL,
    state TEXT DEFAULT "main_menu",
    last_button_time INTEGER DEFAULT 0,
    role TEXT DEFAULT "user"
);

CREATE TABLE IF NOT EXISTS AdminRate (
    id INTEGER,
    rate INTEGER,
    date TEXT,
    uid INTEGER
);

CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    content_type TEXT NOT NULL,
    content_text TEXT,
    message_id INTEGER NOT NULL,
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES tickets(thread_id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS blacklist (
    id INTEGER NOT NULL,
    addedby INTEGER,
    reason TEXT
);

CREATE TABLE IF NOT EXISTS specialists (
    user_id INTEGER PRIMARY KEY,
    role TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tickets (
    thread_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    username TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_blacklist_id ON blacklist (id);
CREATE INDEX IF NOT EXISTS idx_users_id ON users (id);