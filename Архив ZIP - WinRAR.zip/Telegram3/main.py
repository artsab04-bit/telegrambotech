# Изменения: Добавлен импорт markups в setup_handlers если нужно. Улучшена инициализация с добавлением DEV в specialists если не существует.
import logging
from time import sleep
import telebot as tb
from telebot.apihelper import ApiTelegramException
from telebot.types import Message
from core.Logers import LoggingConfigurations
from core.db.setup import setup_database
from core.config import TOKEN, GROUP_ID, DEV, APP_PATHS
from core.db.settings import Settings
from core.db import Ticket
import os
import threading
import sys
import sqlite3
import pytz
from datetime import datetime, timedelta
import requests
import certifi

os.environ['REQUESTS_CA_BUNDLE'] = certifi.where()

logger = LoggingConfigurations.main

class BotRunner:
    def __init__(self):
        self.bot = None
        self.max_restart_attempts = 5
        self.restart_count = 0
        self.should_stop = False
        self.auto_close_thread = None

    def validate_environment(self):
        if not TOKEN or not isinstance(TOKEN, str):
            raise ValueError("Токен бота не задан или имеет неверный формат!")
        if not GROUP_ID:
            raise ValueError("GROUP_ID не задан в конфигурации")
        if not DEV:
            logger.warning("DEV ID не задан, некоторые функции будут недоступны")

    def initialize_bot(self):
        self.bot = tb.TeleBot(
            TOKEN,
            parse_mode='HTML',
            threaded=True,
            num_threads=4,
            skip_pending=True
        )
        logger.info(f"Бот инициализирован с токеном: {TOKEN[:10]}...")

    def setup_handlers(self):
        from core.handlers.admin import setup_admin_handlers
        from core.handlers.user import setup_user_handlers
        from core.handlers.updates import setup_updates_handlers
        from core.handlers.inline_callbacks import setup_inline_callbacks
        from core.handlers.dev import setup_dev_handlers
        setup_admin_handlers(self.bot)
        setup_user_handlers(self.bot)
        setup_updates_handlers(self.bot)
        setup_inline_callbacks(self.bot)
        setup_dev_handlers(self.bot)

        @self.bot.message_handler(commands=['stop'])
        def handle_stop(message: Message):
            if message.from_user.id == DEV:
                logger.info("Бот останавливается по команде /stop")
                self.bot.send_message(message.chat.id, "Бот останавливается.")
                self.stop()
            else:
                self.bot.reply_to(message, "Доступ запрещён.")

        logger.info("Все обработчики успешно зарегистрированы")

    def check_bot_permissions(self):
        try:
            chat_member = self.bot.get_chat_member(GROUP_ID, self.bot.get_me().id)
            if not chat_member.can_manage_topics:
                raise ValueError("Бот не имеет прав на управление темами в группе")
            logger.info("Права бота проверены успешно")
        except Exception as e:
            logger.error(f"Ошибка проверки прав: {e}")
            raise

    def start_ticket_auto_close(self):
        def auto_close_loop():
            while not self.should_stop:
                ticket_obj = Ticket()
                settings = Settings()
                conn = None
                cursor = None
                try:
                    inactivity_value = settings.get('inactivity_hours')
                    try:
                        inactivity_hours = int(inactivity_value) if inactivity_value else 24
                    except ValueError:
                        inactivity_hours = 24
                    conn = sqlite3.connect(APP_PATHS["database"])
                    cursor = conn.cursor()
                    cursor.execute("SELECT thread_id, user_id, last_activity FROM tickets WHERE status = 'open'")
                    tickets = cursor.fetchall()
                    current_time = datetime.now()
                    for thread_id, user_id, last_activity in tickets:
                        last_activity_time = datetime.strptime(last_activity, '%Y-%m-%d %H:%M:%S')
                        if current_time - last_activity_time > timedelta(hours=inactivity_hours):
                            ticket_obj.close_ticket_auto(thread_id, user_id, self.bot, inactivity_hours=inactivity_hours)
                except Exception as e:
                    logger.error(f"Ошибка в авто-закрытии тикетов: {e}")
                finally:
                    if cursor:
                        cursor.close()
                    if conn:
                        conn.close()
                    del ticket_obj
                    del settings
                sleep(3600)  # Проверка каждый час

        self.auto_close_thread = threading.Thread(target=auto_close_loop, daemon=True)
        self.auto_close_thread.start()

    def notify_admins_new_ticket(self, ticket_id):
        admins = []  # Получить список админов из БД
        for admin_id in admins:
            self.bot.send_message(admin_id, f"Новый тикет: {ticket_id}")

    def get_bot_stats(self):
        # Логика статистики: кол-во тикетов, пользователей, банов
        pass

    def run(self):
        if self.should_stop:
            return
        try:
            self.validate_environment()
            self.initialize_bot()
            setup_database()
            Settings()
            conn = sqlite3.connect(APP_PATHS["database"])
            cursor = conn.cursor()
            cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('night_mode', '0')")
            cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('inactivity_hours', '24')")
            # Добавление DEV как admin если не существует
            cursor.execute("INSERT OR IGNORE INTO specialists (user_id, role) VALUES (?, ?)", (DEV, 'admin'))
            conn.commit()
            cursor.close()
            conn.close()
            self.setup_handlers()
            self.check_bot_permissions()
            self.start_ticket_auto_close()
            logger.info("Бот успешно запущен")
            self.bot.infinity_polling(
                timeout=15,
                long_polling_timeout=45,
                logger_level=logging.INFO,
                allowed_updates=['message', 'callback_query']
            )
        except requests.exceptions.SSLError as ssl_err:
            logger.error(f"SSL ошибка: {ssl_err}. Пытаемся перезапуск с задержкой.")
            sleep(5)
            self.run()
        except requests.exceptions.ConnectionError as conn_err:
            logger.error(f"Сетевая ошибка: {conn_err}. Перезапуск polling.")
            sleep(5)
            self.run()
        except Exception as e:
            logger.critical(f"Критическая ошибка: {e}", exc_info=True)
            if not self.should_stop:
                self.handle_restart()

    def handle_restart(self):
        self.restart_count += 1
        if self.restart_count >= self.max_restart_attempts:
            logger.error(f"Достигнут лимит перезапусков ({self.max_restart_attempts})")
            return
        delay = min(30, 2 ** self.restart_count)
        logger.info(f"Перезапуск через {delay} сек (попытка {self.restart_count}/{self.max_restart_attempts})")
        sleep(delay)
        self.run()

    def stop(self):
        self.should_stop = True
        if self.bot:
            try:
                self.bot.stop_polling()
                logger.info("Бот остановлен успешно")
            except Exception as e:
                logger.error(f"Ошибка при остановке бота: {e}")
            finally:
                sys.exit(0)

if __name__ == '__main__':
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('logs/bot.log', encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    bot_runner = BotRunner()
    try:
        bot_runner.run()
    except KeyboardInterrupt:
        bot_runner.stop()
        logger.info("Бот остановлен по запросу пользователя (Ctrl+C)")
    except Exception as e:
        bot_runner.stop()
        logger.critical(f"Фатальная ошибка: {e}", exc_info=True)
    finally:
        bot_runner.stop()
