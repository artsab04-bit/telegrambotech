# Изменения: Улучшена пересылка от саппорта клиенту с обработкой blocked/deactivated (проблема 1). Добавлена выгрузка истории в .txt с полным захватом сообщений, включая медиа-описания (проблема 4). Добавлена функция напоминания о неактивности. Улучшена обработка service сообщений.
import uuid
import time
from datetime import datetime
import pytz
from telebot import TeleBot
from telebot.types import Message, ReplyKeyboardRemove
from telebot.util import content_type_service, content_type_media
from core.config import GROUP_ID, DEV, ticket_creation_lock
from core.markups import main_menu_markup
from data.TEXT_MESSAGES import CREATED, MANUAL_CLOSE, AVERAGE_RESPONSE, WELCOME
from core.db import User, Messages, BlackList, Ticket
from core.types import AppMessage
from core.Logers import LoggingConfigurations
import telebot.apihelper
logger = LoggingConfigurations.main

def setup_updates_handlers(bot: TeleBot):
    def is_support(user_id: int) -> bool:
        user_obj = User(user_id)
        role = user_obj.get_role(user_id)
        user_obj.exit()
        return role in ['admin', 'senior_specialist', 'specialist']

    @bot.message_handler(commands=["close"], chat_types=["supergroup"], func=lambda m: m.chat.id == GROUP_ID and m.is_topic_message)
    def close_ticket_support(message: Message):
        if not is_support(message.from_user.id):
            bot.reply_to(message, "Доступ запрещен.")
            return
        ticket_id = message.message_thread_id
        user_obj = User(ticketID=ticket_id)
        ticket_obj = Ticket()
        try:
            if not user_obj.userdata:
                bot.reply_to(message, "Тикет не найден.")
                return
            closed_by = message.from_user.full_name
            if message.from_user.username:
                closed_by = f"{message.from_user.full_name} (@{message.from_user.username})"
            history_path = ticket_obj.close_ticket_manual(ticket_id, user_obj.userdata.id, bot)
            bot.send_message(GROUP_ID, f"Тикет {ticket_id}. Закрыл {closed_by}.")
            if history_path:
                with open(history_path, 'rb') as f:
                    bot.send_document(GROUP_ID, f)
        finally:
            user_obj.exit()
            del ticket_obj

    @bot.message_handler(
        content_types=content_type_media,
        chat_types="private"
    )
    def handle_user_message(message: Message):
        user_id = message.from_user.id
        user_name = message.from_user.username or message.from_user.full_name
        user_obj = User(user_id, user_name)
        ticket_obj = Ticket()
        try:
            if user_obj.userdata.state not in ["ticket_mode", "awaiting_ticket_message"]:
                return
            if BlackList().is_blacklisted(user_id):
                ban_info = BlackList().get_ban_info(user_id)
                response = (
                    f"⛔ Вы забанены в этом боте\n\n"
                    f"Причина: {ban_info[2] or 'не указана'}\n"
                    f"Заблокировала команда поддержки Hyper\n"
                    f"Дата: {ban_info[3]}"
                )
                bot.send_message(user_id, response)
                return
            current_time = int(time.time())
            if current_time - user_obj.userdata.last_message_time < 1:
                spam_msg = "⚠️Не спамьте сообщениями!" if user_obj.userdata.language == 'ru' else "⚠️Do not spam messages!"
                bot.send_message(user_id, spam_msg)
            user_obj.set_last_message_time(current_time)
            with ticket_creation_lock:
                ticket_id = ticket_obj.get_by_user_id(user_id)
                if ticket_id is None:
                    try:
                        forum_topic = bot.create_forum_topic(GROUP_ID, user_name)
                        ticket_id = forum_topic.message_thread_id
                        topic = user_obj.userdata.selected_topic if hasattr(user_obj.userdata, "selected_topic") else None
                        ticket_obj.create(ticket_id, user_id, user_name, topic=topic)
                        bot.send_message(user_id, CREATED[user_obj.userdata.language], reply_markup=ReplyKeyboardRemove())
                        avg_response = Messages().get_average_support_response_time(48)
                        if avg_response is not None:
                            avg_minutes = int(round(avg_response / 60))
                            avg_text = f"{avg_minutes} мин." if user_obj.userdata.language == 'ru' else f"{avg_minutes} min"
                            bot.send_message(
                                user_id,
                                AVERAGE_RESPONSE[user_obj.userdata.language].format(avg_time=avg_text)
                            )
                        lang_text = "Русский" if user_obj.userdata.language == 'ru' else "Английский"
                        bot.send_message(
                            GROUP_ID,
                            f"✅ Создан тикет {ticket_id}:\n"
                            f"⚙️ ID пользователя: {user_obj.userdata.id}\n"
                            f"👤 Username: @{user_obj.userdata.username}\n"
                            f"🌐 Язык: {lang_text}" + (f"\n📝 Тема: {topic}" if topic else ""),
                            message_thread_id=ticket_id
                        )
                        user_obj.set_ticket(ticket_id)
                        user_obj.set_state("ticket_mode")
                        if topic:
                            bot.send_message(GROUP_ID, f"<b>Выбранная тема:</b> {topic}", message_thread_id=ticket_id)
                    except Exception as create_err:
                        logger.error(f"Ошибка создания темы: {create_err}")
                        bot.send_message(user_id, "⚠️ Ошибка при создании тикета.")
                        return
            if message.content_type == "text":
                bot.send_message(
                    GROUP_ID,
                    f"<b>Сообщение от пользователя:</b>\n{message.text}",
                    message_thread_id=ticket_id
                )
            else:
                bot.copy_message(
                    GROUP_ID,
                    message.chat.id,
                    message.message_id,
                    message_thread_id=ticket_id
                )
            if user_obj.userdata.state == "awaiting_ticket_message":
                user_obj.set_state("ticket_mode")
            Messages().add(AppMessage(
                TicketID=ticket_id,
                Message=message,
                TicketMessageID=message.message_id,
                MessageFromID=user_id,
                SenderRole="client",
                SenderName=user_name
            ))
            ticket_obj.update_last_activity(ticket_id)
            ticket_obj.clear_support_reply_time(ticket_id)
        except Exception as err:
            error_msg = str(err).lower()
            if "blocked" in error_msg:
                bot.send_message(GROUP_ID, "Пользователь заблокировал бота. Тикет будет удален.", message_thread_id=ticket_id)
            elif "deactivated" in error_msg:
                bot.send_message(GROUP_ID, "Аккаунт пользователя деактивирован. Тикет будет удален.", message_thread_id=ticket_id)
            else:
                logger.error(f"Ошибка пересылки сообщения: {err}")
            try:
                bot.delete_forum_topic(GROUP_ID, ticket_id)
            except Exception as delete_err:
                if "TOPIC_NOT_MODIFIED" not in str(delete_err):
                    logger.error(f"Ошибка удаления темы: {delete_err}")
            user_obj.set_ticket(-99999)
            user_obj.set_state("main_menu")
        finally:
            user_obj.exit()
            del ticket_obj

    @bot.message_handler(
        chat_types="supergroup",
        content_types=content_type_media,
        func=lambda m: m.chat.id == GROUP_ID and m.is_topic_message
    )
    def handle_support_message(message: Message):
        ticket_id = message.message_thread_id
        ticket_obj = Ticket()
        user_obj = User(ticketID=ticket_id)
        try:
            if user_obj.userdata is None:
                return
            if message.content_type == "text":
                bot.send_message(user_obj.userdata.id, message.text)
            else:
                bot.copy_message(user_obj.userdata.id, GROUP_ID, message.message_id)
            support_name = message.from_user.username or message.from_user.full_name
            Messages().add(AppMessage(
                TicketID=ticket_id,
                Message=message,
                TicketMessageID=message.message_id,
                MessageFromID=message.from_user.id,
                SenderRole="support",
                SenderName=support_name
            ))
            ticket_obj.update_last_activity(ticket_id)
            ticket_obj.set_support_reply_time(ticket_id)
        except Exception as err:
            error_msg = str(err).lower()
            if "blocked" in error_msg or "deactivated" in error_msg:
                bot.send_message(GROUP_ID, f"Ошибка отправки: пользователь заблокировал бота или деактивирован. Тикет {ticket_id} закрыт.", message_thread_id=ticket_id)
                ticket_obj.close_ticket_auto(ticket_id, user_obj.userdata.id, bot)
            else:
                logger.error(f"Ошибка пересылки от саппорта: {err}")
        finally:
            user_obj.exit()
            del ticket_obj

    @bot.message_handler(content_types="forum_topic_closed")
    def handle_closed_topic(message: Message):
        if GROUP_ID != int(message.chat.id) or not message.is_topic_message:
            return
        ticket_id = message.message_thread_id
        user_obj = None
        ticket_obj = Ticket()
        try:
            status = ticket_obj.get_status(ticket_id)
            if status and status != "open":
                return
            user_obj = User(ticketID=ticket_id)
            if not user_obj.userdata:
                logger.warning(f"Пользователь для закрытого тикета {ticket_id} не найден")
                return
            history_path = ticket_obj.save_history_to_txt(ticket_id)
            ticket_obj.update_status(ticket_id, "manual_closed")
            bot.delete_forum_topic(GROUP_ID, ticket_id)
            bot.send_message(
                user_obj.userdata.id,
                MANUAL_CLOSE[user_obj.userdata.language].format(ticket_id=ticket_id)
            )
            Messages().delete_by_ticket(ticket_id)
            user_obj.set_ticket(-99999)
            user_obj.set_state("main_menu")
            bot.send_message(
                user_obj.userdata.id,
                WELCOME[user_obj.userdata.language],
                reply_markup=main_menu_markup(user_obj.userdata.language)
            )
            closed_by = message.from_user.full_name if message.from_user else "Система"
            if message.from_user and message.from_user.username:
                closed_by = f"{message.from_user.full_name} (@{message.from_user.username})"
            bot.send_message(GROUP_ID, f"Тикет {ticket_id}. Закрыл {closed_by}.")
            if history_path:
                with open(history_path, 'rb') as f:
                    bot.send_document(GROUP_ID, f)
        except Exception as err:
            logger.error(f"Ошибка обработки закрытия тикета: {err}")
        finally:
            if user_obj is not None:
                user_obj.exit()
            del ticket_obj

    @bot.message_handler(content_types=content_type_service)
    def handle_service_message(message: Message):
        try:
            bot.delete_message(message.chat.id, message.message_id)
        except Exception as e:
            logger.debug(f"Не удалось удалить служебное сообщение: {e}")
