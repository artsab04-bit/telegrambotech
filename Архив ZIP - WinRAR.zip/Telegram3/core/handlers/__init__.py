from .user import setup_user_handlers
from .admin import setup_admin_handlers
from .updates import setup_updates_handlers
from .inline_callbacks import setup_inline_callbacks

# Явное указание экспортируемых имен
__all__ = [
    'setup_user_handlers',
    'setup_admin_handlers', 
    'setup_updates_handlers',
    'setup_inline_callbacks'
]

# Условный импорт dev-обработчиков только в development-режиме
try:
    from .dev import setup_dev_handlers
    __all__.append('setup_dev_handlers')
except ImportError:
    pass
