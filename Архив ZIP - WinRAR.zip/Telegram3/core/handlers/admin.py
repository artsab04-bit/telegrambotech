# Изменения: Полностью восстановлена оригинальная логика кнопок админ-панели с точным совпадением текста кнопок из markups.py (проблема с 95% кнопок). Добавлены обработчики для "🌙 Ночной режим" (toggle) и "ССЫЛКА НА ЧАТ". Specialists_menu - ReplyKeyboard как в оригинале, с точным текстом без лишних пробелов. Фикс для add/demote/list специалистов. Улучшена is_admin с senior для ограниченных действий. Все кнопки теперь работают.
from telebot import TeleBot
from telebot.types import (
    Message,
    ReplyKeyboardRemove,
    ReplyKeyboardMarkup,
    KeyboardButton,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)
from core.config import GROUP_ID, DEV, APP_PATHS
from core.Logers import LoggingConfigurations
from core.db import User, BlackList, Ticket, Settings, Messages
from core.markups import admin_panel_markup, main_menu_markup, specialists_menu_markup
from data.TEXT_MESSAGES import WELCOME
import sqlite3
import telebot.apihelper

logger = LoggingConfigurations.main

INACTIVE_TICKET_CLOSE_MESSAGE = (
    "🔒Ваш тикет #{ticket_id} закрыт из-за неактивности! Если у вас есть какие-либо вопросы, пожалуйста, создайте тикет и опишите вашу проблему.\n"
    "Пожалуйста запомните номер тикета, если вы хотите задать вопрос по старому тикету."
)

def notify_inactive_ticket(bot: TeleBot, ticket_id: int) -> None:
    markup = InlineKeyboardMarkup()
    markup.add(
        InlineKeyboardButton("Закрыть из-за неактивности", callback_data=f"inactive_close:{ticket_id}"),
        InlineKeyboardButton("Посмотреть чат", callback_data=f"inactive_view:{ticket_id}")
    )
    bot.send_message(
        GROUP_ID,
        f"⚠️ Превышено время неактивности по тикету {ticket_id}.",
        reply_markup=markup
    )

def setup_admin_handlers(bot: TeleBot):
    def is_admin(user_id: int) -> bool:
        user_obj = User(user_id)
        role = user_obj.get_role(user_id)
        user_obj.exit()
        return role in ['admin', 'senior_specialist', 'specialist']

    def is_senior_admin(user_id: int) -> bool:
        user_obj = User(user_id)
        role = user_obj.get_role(user_id)
        user_obj.exit()
        return role in ['admin', 'senior_specialist']

    @bot.message_handler(commands=["admin"], chat_types=["private"])
    def enter_admin_panel(message: Message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "Доступ запрещен. Эта команда доступна только администраторам.")
            logger.warning(f"Попытка входа в админ-панель неадмином user_id={message.from_user.id}")
            return
        bot.send_message(message.chat.id, "Добро пожаловать в админ-панель!", reply_markup=admin_panel_markup())
        user_obj = User(message.from_user.id)
        user_obj.set_state("admin_panel")
        user_obj.exit()
        logger.info(f"Админ {message.from_user.id} вошел в панель")


    @bot.message_handler(commands=["admin"], func=lambda m: m.chat.type != "private")
    def admin_private_only(message: Message):
        bot.reply_to(message, "Команда /admin доступна только в личных сообщениях с ботом.")

    @bot.callback_query_handler(func=lambda call: call.data.startswith(("inactive_close:", "inactive_view:")))
    def handle_inactive_ticket_action(call):
        action, ticket_id_str = call.data.split(":", 1)
        try:
            ticket_id = int(ticket_id_str)
        except ValueError:
            bot.answer_callback_query(call.id, "Некорректный ID тикета.")
            return

        if action == "inactive_view":
            bot.answer_callback_query(call.id, "Откройте тикет по кнопке Посмотреть тикет.")
            return

        user_obj = User(ticketID=ticket_id)
        if not user_obj.userdata:
            bot.answer_callback_query(call.id, "Пользователь не найден.")
            return
        ticket_obj = Ticket()
        try:
            ticket_obj.close_ticket_auto(
                ticket_id,
                user_obj.userdata.id,
                bot,
                close_message=INACTIVE_TICKET_CLOSE_MESSAGE.format(ticket_id=ticket_id)
            )
            closed_by = call.from_user.full_name if call.from_user else "Система"
            if call.from_user and call.from_user.username:
                closed_by = f"{call.from_user.full_name} (@{call.from_user.username})"
            bot.send_message(GROUP_ID, f"Тикет {ticket_id}. Закрыл {closed_by}.")
            bot.answer_callback_query(call.id, "Тикет закрыт из-за неактивности.")
        finally:
            user_obj.exit()
            del ticket_obj

    @bot.message_handler(commands=["opentickets"], chat_types=["supergroup"], func=lambda m: m.chat.id == GROUP_ID)
    def open_tickets(message: Message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "Доступ запрещен.")
            return
        ticket_obj = Ticket()
        try:
            tickets = ticket_obj.list_open_tickets()
            if not tickets:
                bot.reply_to(message, "Открытых тикетов нет.")
                return
            lines = ["Открытые тикеты:"]
            for thread_id, user_id, username, topic, created_at in tickets:
                lines.append(f"#{thread_id} | user={user_id} (@{username}) | тема: {topic or 'Не указана'} | создан: {created_at}")
            bot.reply_to(message, "\n".join(lines))
        finally:
            del ticket_obj

    @bot.message_handler(func=lambda m: m.text in ["Ув. Неактивности", "Inactivity Alert"] and is_senior_admin(m.from_user.id))
    def set_inactivity_alert(message: Message):
        markup = ReplyKeyboardMarkup(resize_keyboard=True)
        markup.add("Отменить")
        bot.send_message(message.chat.id, "Введите время неактивности в минутах:", reply_markup=markup)
        bot.register_next_step_handler(message, process_set_inactivity_alert)

    def process_set_inactivity_alert(message: Message):
        if message.text == "Отменить":
            bot.send_message(message.chat.id, "Отменено.", reply_markup=admin_panel_markup())
            return
        try:
            minutes = int(message.text)
            if minutes <= 0:
                raise ValueError
        except ValueError:
            bot.send_message(message.chat.id, "Введите целое число больше 0.", reply_markup=admin_panel_markup())
            return
        Settings().set('inactivity_minutes', str(minutes))
        bot.send_message(message.chat.id, f"Порог неактивности обновлен: {minutes} мин.", reply_markup=admin_panel_markup())

    @bot.message_handler(commands=["help"], chat_types=["supergroup"], func=lambda m: m.chat.id == GROUP_ID)
    def help_command(message: Message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "Доступ запрещен.")
            return
        help_text = """
Доступные команды в #GENERAL:
- /closeticket ID или @username - Принудительно закрыть тикет пользователя. Пример: /closeticket 123456789 или /closeticket @username
- /opentickets - Список открытых тикетов
- /ban ID или @username [reason] - Забанить пользователя. Пример: /ban 123456789 Спам
- /unban ID или @username - Разбанить пользователя. Пример: /unban 123456789
- /banlist - Список забаненных пользователей
- /admin - Вход в админ-панель (только для админов)
"""
        bot.reply_to(message, help_text)

    @bot.message_handler(func=lambda m: m.text == "📩 Сделать рассылку" and is_senior_admin(m.from_user.id))
    def start_broadcast(message: Message):
        markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
        markup.add(KeyboardButton("Отменить"))
        bot.send_message(message.chat.id, "Введите текст сообщения для рассылки всем пользователям:", reply_markup=markup)
        bot.register_next_step_handler(message, process_broadcast)
        logger.info(f"Админ {message.from_user.id} начал рассылку")

    def process_broadcast(message: Message):
        if not is_senior_admin(message.from_user.id):
            return
        if message.text == "Отменить":
            bot.send_message(message.chat.id, "Рассылка отменена.", reply_markup=ReplyKeyboardRemove())
            return
        try:
            conn = sqlite3.connect(APP_PATHS["database"])
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM users")
            users = cursor.fetchall()
            cursor.close()
            conn.close()
            success = 0
            failed = 0
            for user in users:
                try:
                    bot.send_message(user[0], message.text)
                    success += 1
                except:
                    failed += 1
            bot.send_message(message.chat.id, f"Рассылка завершена: успешно {success}, неудачно {failed}", reply_markup=ReplyKeyboardRemove())
        except Exception as e:
            bot.send_message(message.chat.id, f"Ошибка рассылки: {e}", reply_markup=ReplyKeyboardRemove())

    @bot.message_handler(func=lambda m: m.text == "👥 Узнать количество пользователей" and is_admin(m.from_user.id))
    def get_user_count(message: Message):
        conn = sqlite3.connect(APP_PATHS["database"])
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users")
        total = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM users WHERE created_at > DATETIME('now', '-24 hours')")
        new_24h = cursor.fetchone()[0]
        cursor.close()
        conn.close()
        bot.reply_to(message, f"Общее пользователей: {total}\nНовых за 24ч: {new_24h}")

    @bot.message_handler(func=lambda m: m.text == "🛡 Специалисты" and is_senior_admin(m.from_user.id))
    def specialists_menu(message: Message):
        bot.send_message(message.chat.id, "Управление специалистами", reply_markup=specialists_menu_markup())
        user_obj = User(message.from_user.id)
        user_obj.set_state("specialists_menu")
        user_obj.exit()

    @bot.message_handler(func=lambda m: m.text == "✅ Добавить специалист" and is_senior_admin(m.from_user.id))
    def add_specialist(message: Message):
        markup = ReplyKeyboardMarkup(resize_keyboard=True)
        markup.add("Отменить")
        bot.send_message(message.chat.id, "Введите ID или @username специалиста:", reply_markup=markup)
        bot.register_next_step_handler(message, process_add_specialist)

    def process_add_specialist(message: Message):
        if message.text == "Отменить":
            bot.send_message(message.chat.id, "Отменено.", reply_markup=admin_panel_markup())
            return
        target = message.text
        if target.startswith('@'):
            target = target[1:]
            conn = sqlite3.connect(APP_PATHS["database"])
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM users WHERE username = ?", (target,))
            result = cursor.fetchone()
            cursor.close()
            conn.close()
            if not result:
                bot.reply_to(message, "Пользователь не найден.")
                return
            user_id = result[0]
        else:
            try:
                user_id = int(target)
            except ValueError:
                bot.reply_to(message, "Неверный формат.")
                return
        conn = sqlite3.connect(APP_PATHS["database"])
        cursor = conn.cursor()
        cursor.execute("INSERT OR REPLACE INTO specialists (user_id, role) VALUES (?, ?)", (user_id, 'specialist'))
        conn.commit()
        cursor.close()
        conn.close()
        bot.send_message(message.chat.id, f"Специалист {user_id} добавлен.", reply_markup=admin_panel_markup())

    @bot.message_handler(func=lambda m: m.text == "❌ Разжаловать специалист" and is_senior_admin(m.from_user.id))
    def demote_specialist(message: Message):
        markup = ReplyKeyboardMarkup(resize_keyboard=True)
        markup.add("Отменить")
        bot.send_message(message.chat.id, "Введите ID или @username специалиста:", reply_markup=markup)
        bot.register_next_step_handler(message, process_demote_specialist)

    def process_demote_specialist(message: Message):
        if message.text == "Отменить":
            bot.send_message(message.chat.id, "Отменено.", reply_markup=admin_panel_markup())
            return
        target = message.text
        if target.startswith('@'):
            target = target[1:]
            conn = sqlite3.connect(APP_PATHS["database"])
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM users WHERE username = ?", (target,))
            result = cursor.fetchone()
            cursor.close()
            conn.close()
            if not result:
                bot.reply_to(message, "Пользователь не найден.")
                return
            user_id = result[0]
        else:
            try:
                user_id = int(target)
            except ValueError:
                bot.reply_to(message, "Неверный формат.")
                return
        conn = sqlite3.connect(APP_PATHS["database"])
        cursor = conn.cursor()
        cursor.execute("DELETE FROM specialists WHERE user_id = ?", (user_id,))
        conn.commit()
        cursor.close()
        conn.close()
        bot.send_message(message.chat.id, f"Специалист {user_id} разжалован.", reply_markup=admin_panel_markup())

    @bot.message_handler(func=lambda m: m.text == "📋 Получить список специалистов" and is_senior_admin(m.from_user.id))
    def list_specialists(message: Message):
        conn = sqlite3.connect(APP_PATHS["database"])
        cursor = conn.cursor()
        cursor.execute("SELECT user_id, role FROM specialists")
        specialists = cursor.fetchall()
        cursor.close()
        conn.close()
        if not specialists:
            bot.reply_to(message, "Нет специалистов.")
            return
        response = "Список специалистов:\n"
        for spec in specialists:
            user_id, role = spec
            response += f"ID: {user_id}, Role: {role}\n"
        bot.reply_to(message, response)

    @bot.message_handler(func=lambda m: m.text == "🌙 Ночной режим" and is_senior_admin(m.from_user.id))
    def toggle_night_mode(message: Message):
        settings = Settings()
        current = settings.get('night_mode')
        new_mode = '0' if current == '1' else '1'
        settings.set('night_mode', new_mode)
        status = "включен" if new_mode == '1' else "выключен"
        bot.reply_to(message, f"Ночной режим {status}.")
        del settings

    @bot.message_handler(func=lambda m: m.text in ["ССЫЛКА НА БАН", "BAN LINK"] and is_senior_admin(m.from_user.id))
    def edit_ban_link(message: Message):
        markup = ReplyKeyboardMarkup(resize_keyboard=True)
        markup.add("Отменить")
        bot.send_message(message.chat.id, "Введите новую ссылку для формы бана:", reply_markup=markup)
        bot.register_next_step_handler(message, process_edit_ban_link)

    def process_edit_ban_link(message: Message):
        if message.text == "Отменить":
            bot.send_message(message.chat.id, "Отменено.", reply_markup=admin_panel_markup())
            return
        Settings().set('ban_link', message.text)
        bot.send_message(message.chat.id, "Ссылка обновлена.", reply_markup=admin_panel_markup())

    @bot.message_handler(func=lambda m: m.text == "КНОПКА ИНСТРУКЦИИ" and is_senior_admin(m.from_user.id))
    def edit_errors_link(message: Message):
        markup = ReplyKeyboardMarkup(resize_keyboard=True)
        markup.add("Отменить")
        bot.send_message(message.chat.id, "Введите новую ссылку на инструкцию:", reply_markup=markup)
        bot.register_next_step_handler(message, process_edit_errors_link)

    def process_edit_errors_link(message: Message):
        if message.text == "Отменить":
            bot.send_message(message.chat.id, "Отменено.", reply_markup=admin_panel_markup())
            return
        Settings().set('errors_link', message.text)
        bot.send_message(message.chat.id, "Ссылка обновлена.", reply_markup=admin_panel_markup())

    @bot.message_handler(func=lambda m: m.text == "ССЫЛКА НА ЧАТ" and is_senior_admin(m.from_user.id))
    def set_chat_link(message: Message):
        markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
        markup.add(KeyboardButton("Отменить"))
        bot.send_message(message.chat.id, "Введите новую ссылку на чат:", reply_markup=markup)
        bot.register_next_step_handler(message, process_set_chat_link)

    def process_set_chat_link(message: Message):
        if message.text == "Отменить":
            bot.send_message(message.chat.id, "Изменение отменено.", reply_markup=admin_panel_markup())
            return
        settings = Settings()
        settings.set('chat_link', message.text)
        bot.send_message(message.chat.id, f"Ссылка на чат обновлена: {message.text}", reply_markup=admin_panel_markup())
        del settings

    @bot.message_handler(func=lambda m: m.text in ["⚙️ Выйти из админ-панели", "⚙️ Exit Admin Panel"] and is_admin(m.from_user.id))
    def exit_admin_panel(message: Message):
        user_obj = User(message.from_user.id)
        user_obj.set_state("main_menu")
        bot.send_message(message.chat.id, WELCOME[user_obj.userdata.language], reply_markup=main_menu_markup(user_obj.userdata.language))
        user_obj.exit()

    @bot.message_handler(commands=["ban"])
    def ban_user(message: Message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "Доступ запрещен.")
            return
        try:
            parts = message.text.split(maxsplit=2)
            if len(parts) < 2:
                bot.reply_to(message, "Формат: /ban user_id или @username [reason]")
                return
            target = parts[1]
            reason = parts[2] if len(parts) > 2 else None
            if target.startswith('@'):
                target = target[1:]
                conn = sqlite3.connect(APP_PATHS["database"])
                cursor = conn.cursor()
                cursor.execute("SELECT id FROM users WHERE username = ?", (target,))
                result = cursor.fetchone()
                cursor.close()
                conn.close()
                if not result:
                    bot.reply_to(message, "Пользователь не найден.")
                    return
                target_user_id = result[0]
            else:
                target_user_id = int(target)
            blacklist = BlackList()
            if blacklist.add_to_blacklist(target_user_id, message.from_user.id, reason):
                bot.reply_to(message, f"Пользователь {target_user_id} забанен.")
                logger.info(f"Пользователь {target_user_id} забанен админом {message.from_user.id}")
            else:
                bot.reply_to(message, "Ошибка при бане.")
        except ValueError:
            bot.reply_to(message, "Неверный формат user_id.")
        except Exception as e:
            logger.error(f"Ошибка бана: {e}")
            bot.reply_to(message, f"Ошибка: {e}")

    @bot.message_handler(commands=["unban"])
    def unban_user(message: Message):
        if not is_admin(message.from_user.id):
            bot.reply_to(message, "Доступ запрещен.")
            return
        try:
            parts = message.text.split()
            if len(parts) < 2:
                bot.reply_to(message, "Формат: /unban user_id или @username")
                return
            target = parts[1]
            if target.startswith('@'):
                target = target[1:]
                conn = sqlite3.connect(APP_PATHS["database"])
                cursor = conn.cursor()
                cursor.execute("SELECT id FROM users WHERE username = ?", (target,))
                result = cursor.fetchone()
                cursor.close()
                conn.close()
                if not result:
                    bot.reply_to(message, "Пользователь не найден.")
                    return
                target_user_id = result[0]
                target_username = target
            else:
                target_user_id = int(target)
                target_username = "ID"
            blacklist = BlackList()
            if blacklist.remove_from_blacklist(target_user_id):
                bot.reply_to(message, f"Пользователь {target_user_id} ({target_username}) разбанен.")
                logger.info(f"Пользователь {target_user_id} разбанен админом {message.from_user.id}")
            else:
                bot.reply_to(message, "Пользователь не в блэклисте.")
        except ValueError:
            bot.reply_to(message, "Неверный формат user_id.")
        except Exception as e:
            logger.error(f"Ошибка разбана: {e}")
            bot.reply_to(message, f"Ошибка: {e}")

    @bot.message_handler(commands=["banlist"])
    def banlist(message: Message):
        if not is_admin(message.from_user.id):
            try:
                chat_member = bot.get_chat_member(GROUP_ID, message.from_user.id)
                if chat_member.status not in ["administrator", "creator"]:
                    bot.reply_to(message, "Эта команда доступна только администраторам.")
                    logger.warning(f"Попытка выполнения /banlist неадмином user_id={message.from_user.id}")
                    return
            except Exception as e:
                logger.error(f"Ошибка проверки статуса админа для user_id={message.from_user.id}: {e}")
                bot.reply_to(message, "Ошибка проверки прав администратора.")
                return
        try:
            conn = sqlite3.connect(APP_PATHS["database"])
            cursor = conn.cursor()
            cursor.execute("""
                SELECT b.id, u.username, b.reason, b.created_at
                FROM blacklist b
                LEFT JOIN users u ON b.id = u.id
                ORDER BY b.created_at DESC
            """)
            banned_users = cursor.fetchall()
            cursor.close()
            conn.close()
            if not banned_users:
                bot.reply_to(message, "Чёрный список пуст.", parse_mode=None)
                return
            response = "Список забаненных пользователей:\n\n"
            for user in banned_users:
                user_id, username, reason, created_at = user
                username = f"@{username}" if username else "Неизвестный"
                reason = reason or "Не указана"
                response += f"ID: {user_id}\nUsername: {username}\nПричина: {reason}\nДата: {created_at}\n\n"
            bot.reply_to(message, response, parse_mode=None)
            logger.info(f"Админ {message.from_user.id} запросил список забаненных пользователей")
         
        except Exception as e:
            logger.error(f"Ошибка получения списка забаненных пользователей: {e}")
            bot.reply_to(message, f"Ошибка: {e}", parse_mode=None)
