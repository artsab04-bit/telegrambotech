from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton

def language_markup():
    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("🇷🇺 Русский", callback_data="lang:ru"),
        InlineKeyboardButton("🇬🇧 English", callback_data="lang:en")
    )
    return markup

def main_menu_markup(lang: str = 'ru'):
    markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
    if lang == 'ru':
        markup.add("✏️ Написать тикет", "💬 Чат пользователей Hyper", "🔄 Сменить язык")
    else:
        markup.add("✏️ Write ticket", "💬 Hyper Users Chat", "🔄 Change language")
    return markup

def admin_panel_markup(lang: str = 'ru'):
    markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
    if lang == 'ru':
        markup.add("📩 Сделать рассылку", "👥 Узнать количество пользователей", "🛡 Специалисты", "🌙 Ночной режим", "ССЫЛКА НА БАН", "ССЫЛКА НА ЧАТ", "⚙️ Выйти из админ-панели")
    else:
        markup.add("📩 Send Broadcast", "👥 Get User Count", "🛡 Specialists", "🌙 Night Mode", "BAN LINK", "CHAT LINK", "⚙️ Exit Admin Panel")
    return markup

def specialists_menu_markup(lang: str = 'ru'):
    markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
    if lang == 'ru':
        markup.add("✅ Добавить специалист", "❌ Разжаловать специалист", "📋 Получить список специалистов", "⚙️ Выйти из админ-панели")
    else:
        markup.add("✅ Add Specialist", "❌ Demote Specialist", "📋 Get Specialists List", "⚙️ Exit Admin Panel")
    return markup

def problem_type_markup(language):
    markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
    if language == 'ru':
        markup.add("🛠 У меня проблема с читом", "⚠️Я получил BAN в игре", "🌐Сотрудничество с нами", "❓Другой вопрос")
    else:
        markup.add("🛠 I have a problem with the cheat", "⚠️I received a BAN in the game", "🌐Cooperation with us", "❓Other question")
    return markup

def cheat_problem_markup(language):
    markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    if language == 'ru':
        markup.add("🙋‍♂️Мне нужен оператор")
    else:
        markup.add("🙋‍♂️I need an operator")
    return markup
