from dataclasses import dataclass
from telebot.types import MessageID, Message
@dataclass
class UserData:
    id: int
    username: str
    ticketID: int
    language: str
    state: str = "main_menu"
    last_button_time: int = 0
    role: str = "user" # Добавлена роль по умолчанию
    last_message_time: int = 0
    created_at: str = None  # Добавлен created_at
    selected_topic: str = None
@dataclass
class AppMessage:
    TicketID: int
    Message: Message
    TicketMessageID: MessageID
    MessageFromID: int
